/* 
 * File:   varios.h
 * Author: Stephanie Contreras
 *
 * Created on January 13, 2023, 9:17 PM
 */
/************** P R O T O T Y P E S *******************************************/
void MCU_Init(void);
void opciones(unsigned char);




